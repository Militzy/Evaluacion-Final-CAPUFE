# Dashboard Aforos CAPUFE

Este proyecto es un dashboard interactivo desarrollado con [Shiny para Python](https://shiny.posit.co/py/) que analiza los datos de aforo vehicular en la red propia de CAPUFE.

## Estructura del proyecto

- `evaluacion1.py` → Script principal con el dashboard en Shiny
- `estilo.css` → Estilos visuales personalizados para la interfaz
- `Aforos-RedPropia.csv` → 🔺 Debes agregar tú mismo este archivo en la misma carpeta (no incluido)
- `README.txt` → Este archivo con instrucciones

## Requisitos

Instala los paquetes necesarios con:

```
pip install shiny pandas plotly shinywidgets
```

## Cómo ejecutar

Desde una terminal en la carpeta del proyecto (donde está `evaluacion1.py`):

```
shiny run --reload evaluacion1.py
```

Luego abre tu navegador en `http://localhost:8000`.

## Notas

- Asegúrate de tener `Python 3.10+` y de usar un entorno virtual (recomendado).
- El archivo `Aforos-RedPropia.csv` debe estar codificado en `latin1` y tener las columnas originales.
